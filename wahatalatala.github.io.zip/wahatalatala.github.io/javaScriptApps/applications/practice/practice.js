const html_canvas =  document.querySelector("canvas");
const canvas = html_canvas.getContext("2d");
canvas.lineWidth = 1;
canvas.strokeStyle = "blue";
const PI = Math.PI;
function pi (degree){
 alert (2*PI-degree/360*2*PI);
 return 2*PI - degree/180*PI;
}
//canvas.beginPath();
canvas.font = "3em Arial,sans-serif";
canvas.strokeText("hello",50,50,200);
//canvas.stroke ();
canvas.moveTo(150,10);
canvas.lineTo(250,100);
canvas.lineTo(50,100);
canvas.closePath();
canvas.clip();
canvas.fillText("hello",50,50,200);
canvas.fillText("hello",50,100,200);
canvas.stroke();
let image_data = canvas.getImageData(100,50,100,50);
let cc = 0;
html_canvas.addEventListener("touchmove",(event)=>{//if (!cc++)
let t = event.touches[0];
canvas.lineTo(t.clientX,t.clientY);
canvas.stroke ();
console.log(event.touches[0].clientX);
})













let img = document.createElement("img");
img.src = html_canvas.toDataURL();
document.body.append(img);