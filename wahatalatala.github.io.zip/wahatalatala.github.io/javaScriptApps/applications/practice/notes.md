step 0 : read definitive guide to learn javaScript version 7 book chapter 15 or part 15.8 or do the following

step 1 : create html canvas element
for example 
<cavas id="canvas"></canvas>

step 2 : assign canvas element to variable
for example
canvas_element = document.getElentById ("canvas");

step 3 : get context using getContext()
and assignass it to variable
for example
canvas_context = canvas_element.getContext ("2d");
there is 3d for working with webgl

step 4 : call beginPath() to start path
for example
canvas_context.beginpath();

step 5 : set drawingcolor using fillStyle
and\or strokeStyle
for example
canvas_context.fillStyle" = "#3f5612";

step 6 : use drawing method like line , point ,arc , moveTo (witch change your current position).... , to define the path
don,t forget to set width and height properties in the html file ;
you need to use stroke or fill function to draw the path
for example
canvas_contex.arc(5,5,5,0,2*Math.PI,true);

step 7 : use  stroke(used to draw lines) or fill(used to fill shape or area between lines with color) methods (fill , fillRect , fillString ) to fill your shape with color specified by fillStyle()
here example
canvas_context.fill();

step 8 : close path by calling endPath()
here example
canvas_contex.endPath();

example :
const canvas =  document.querySelector("canvas").getContext("2d");
canvas.fillStyle = "#0f0";
canvas.fillRect(200,30,50,200);
canvas.beginPath();
canvas.fillStyle = "blue";
canvas.strokeStyle = "red";
canvas.moveTo(10, 50, );
canvas.lineTo(150, 50);
canvas.arcTo(55,55,100,100,45);
canvas.fill();
canvas.stroke();
canvas.closePath();

more notes :
you can create more than one path 
you can draw without creating path
if there error in these notes tell me