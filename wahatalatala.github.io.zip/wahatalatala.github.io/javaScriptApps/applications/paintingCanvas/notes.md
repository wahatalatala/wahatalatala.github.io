problems :
1:increase lineWidth increase all pathes

notes :
1: to know more about an event write
console.log(event); and then explore more
in the console specially about _proto_

to do list :
  <ol>
  <li>starting degree</li>
  <li>ending degree</li>
  <li>clockwise</li>
  <li>clip</li>
  <li>polygon degree</li>
  <li>close path</li>
  <li>save and load status</li>
  <li>scale , translate</li>
  <li>edit shape size , direction and position after drawing</li>
  <li>free drawing(not now)</li>
  <li>auto draw ex triangle click once in the center or click three different points to decide angles and sizes</li>
  <li>shadow</li>
  <li>opacity</li>
  <li>line width</li>
  <li>font</li>
  <li>connect shapes</li>
  <li>change canvas size </li>
 </ol>